Projet IRESI, écrit par Rémi Hutin et Rémy Sun.

Vous trouverez 5 fichiers dans cette archive :

- rapport.pdf
- projet.py
- parser.py
- rand_hash.py
- et ce README.txt

Le fichier .pdf contient notre compte-rendu. 
Les fichiers .py contiennent le code source. Le code a été écrit avec le langage Python 3.
Les fichier "parser.py" et "rand_hash.py" sont des modules. Le fichier à exécuter est "projet.py", à l'aide de la commande :
python3 projet.py

Pour pouvoir faire fonctionner le code, vous devrez extraire l'archive et ajouter les fichiers "1epahttp.txt", "2sdschttp2.txt" et "3Calgaryaccess_log.txt" dans le même dossier que "projet.py". (Ces fichiers étaient trop volumineux pour être envoyés par mail)
